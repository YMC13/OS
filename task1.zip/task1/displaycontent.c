//
//  displaycontent.c
//  
//
//  Created by WILL on 9/9/16.
//
//

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

int main( int argc,char *argv[3] )
{
    
    //char buf[2];
    char buf[BUFSIZ];
    int fd = open(argv[1],O_RDONLY,0777);
    int fd2;
    if (fd == -1) {
        printf("\n open() failed with error [%s]\n",strerror(errno));
        return 1;
    }
    else {
        printf("\n open() the file: \n");
        while((fd2 = read(fd,buf,1))>0)
        {
            printf("%c",buf[0]);
        }
        
        close(fd);
        
        printf("\n close file \n");
    }
    return 0;
}
