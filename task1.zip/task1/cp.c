//
//  cp.c
//  
//
//  Created by WILL on 9/9/16.
//
//

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

int main( int argc,char *argv[3] )
{

    int fd2;
    fd2 = creat("destination.txt",0666);
    if (fd2 == -1) {
        printf("\n creat() failed with error [%s]\n",strerror(errno));
        return 1;
    }
    else {
        printf("\n creat() Successful\n");
    }

    char buf[BUFSIZ];
    int fd3;
    int fd = open(argv[1],O_RDONLY,0777);
    if (fd == -1) {
        printf("\n open() failed with error [%s]\n",strerror(errno));
        return 1;
    }
    else {
        printf("\n open() the file \n");
        printf("\n copy() the file to destination.txt \n");
        while((fd3 = read(fd,buf,1))>0)
        {
            write(fd2,buf,1);
            
        }
        
        printf("\n finish copy the file to destination.txt \n");
        close(fd);
        printf("\n close file \n");
    }



return 0;
}