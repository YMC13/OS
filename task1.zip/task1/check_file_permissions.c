//
//  check_file_permissions.c
//  
//
//  Created by WILL on 9/9/16.
//
//
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
int main (int argc, char* argv[])
{
    char* filepath = argv[1];
    int returnval;
    // Check file existence
    returnval = access (filepath, F_OK);
    if (returnval == 0)
        printf ("\n %s exists\n", filepath);
    else
    {
        if (errno == ENOENT)
            printf ("%s does not exist\n", filepath);
        else if (errno == EACCES)
            printf ("%s is not accessible\n", filepath);
        return 0;
    }
    // Check read access
    int read_access;
    read_access = access( filepath, R_OK);
    if (read_access == 0) {
        printf("\n %s has read access to file\n", filepath);
    }
    else
        printf("%s: no read access to file.\n", "ACCESS DENIED");

    // Check write access
    int write_access;
    write_access = access( filepath, W_OK);
    if (read_access == 0) {
        printf("\n %s has write access to file\n", filepath);
    }
    else
        printf("%s: no write access to file.\n", "ACCESS DENIED");

    return 0;
}