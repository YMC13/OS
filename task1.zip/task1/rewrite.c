//
//  rewrite.c
//  
//
//  Created by WILL on 9/9/16.
//
//

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

int main( int argc,char *argv[3] )
{
    
    int fd2;
    fd2 = creat("destination.txt",0666);
    if (fd2 == -1) {
        printf("\n creat() failed with error [%s]\n",strerror(errno));
        return 1;
    }
    else {
        printf("\n creat() Successful\n");
    }
    
    char buf[BUFSIZ];
    char *text = "XYZ";
    int fd3;
    int fd = open(argv[1],O_RDONLY);
    if (fd == -1) {
        printf("\n open() failed with error [%s]\n",strerror(errno));
        return 1;
    }
    else {
        printf("\n open() the file \n");
        printf("\n rewirte the file to destination.txt \n");
        while((fd3 = read(fd,buf,100))>0)
        {
            int i=0;
            while (i<fd3) {
                if (buf[i] == '1') {
                    buf[i] = 'A';
                }
                i++;
            }
            write(fd2,buf,fd3);
            write(fd2,text,strlen(text));
            
        }
        
        printf("\n finish rewirte the file to destination.txt \n");
        close(fd);
        printf("\n close file \n");
    }
    
    
    
    return 0;
}